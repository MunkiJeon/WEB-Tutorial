import React from 'react';
import ReactDOM from 'react-dom';

import MineSearch from './MineSearch';

ReactDOM.render(<MineSearch />, document.querySelector('#root'));
