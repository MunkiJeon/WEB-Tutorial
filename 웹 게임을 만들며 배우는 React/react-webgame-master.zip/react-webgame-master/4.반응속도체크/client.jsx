import React from 'react';
import ReactDOM from 'react-dom';

import ResponseCheck from './ResponseCheck.jsx';

ReactDOM.render(<ResponseCheck />, document.querySelector('#root'));
