const React = require('react');
const ReactDOM = require('react-dom');

const GuGuDan = require('./GuGuDan');

ReactDOM.render(<GuGuDan />, document.querySelector('#root'));
