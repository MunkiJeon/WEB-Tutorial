import React from 'react';
import ReactDOM from 'react-dom';

import Games from './Games';

ReactDOM.render(<Games />, document.querySelector('#root'));
