import React from 'react';
import ReactDOM from 'react-dom';

import Lotto from './Lotto';

ReactDOM.render(<Lotto />, document.querySelector('#root'));
