import React from 'react';
import ReactDOM from 'react-dom';

import NumberBaseball from './NumberBaseball';

ReactDOM.render(<NumberBaseball />, document.querySelector('#root'));
