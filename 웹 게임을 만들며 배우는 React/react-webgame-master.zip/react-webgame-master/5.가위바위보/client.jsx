import React from 'react';
import ReactDOM from 'react-dom';

import RSP from './RSP.jsx';

ReactDOM.render(<RSP />, document.querySelector('#root'));
